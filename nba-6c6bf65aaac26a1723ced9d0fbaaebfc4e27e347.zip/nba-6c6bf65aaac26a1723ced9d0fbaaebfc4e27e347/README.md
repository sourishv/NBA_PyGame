I am working on a flask project to make a simple web app to show NBA player stats. Future versions will implement live game data and player comparisons/analysis.
